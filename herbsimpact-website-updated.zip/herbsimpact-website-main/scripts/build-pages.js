#!/usr/bin/env node
/**
 * Build script for Herbal Impact static pages (everything except blog posts,
 * which are handled separately by scripts/build-blog.js).
 *
 * Reads each Markdown+frontmatter file in content/pages/, merges its fields
 * into the matching template in templates/, and writes the final static
 * HTML file to the site root — so Decap CMS edits real, friendly fields
 * (text, images, repeatable lists) instead of one giant raw-HTML blob.
 *
 * Uses the "yaml" package to parse frontmatter, since several pages need
 * proper nested lists (e.g. the Downloads page's list of guides), which a
 * hand-rolled line-by-line parser can't safely handle.
 */

const fs = require('fs');
const path = require('path');
const YAML = require('yaml');

const ROOT = path.resolve(__dirname, '..');
const PAGES_DIR = path.join(ROOT, 'content', 'pages');
const BLOG_DIR = path.join(ROOT, 'content', 'blog');
const TEMPLATES_DIR = path.join(ROOT, 'templates');

// Maps a content/pages/<name>.md file to the template that renders it and
// the static HTML file it produces at the site root.
const PAGE_MAP = {
  'home.md': { template: 'home.html', output: 'index.html' },
  'about.md': { template: 'about.html', output: 'about.html' },
  'blog-index.md': { template: 'blog-index.html', output: 'blog.html' },
  'contact.md': { template: 'contact.html', output: 'contact.html' },
  'downloads.md': { template: 'downloads.html', output: 'downloads.html' },
  'store.md': { template: 'store.html', output: 'store.html' },
  'tools.md': { template: 'tools.html', output: 'tools.html' },
  'videos.md': { template: 'videos.html', output: 'videos.html' },
};

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function parseFrontMatter(raw) {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (!match) {
    throw new Error('Missing front matter block (file must start with "---").');
  }
  return YAML.parse(match[1]) || {};
}

// Replaces every {{KEY}} placeholder in a template with the matching value
// from `fields` (case-insensitive key match on the placeholder name).
function fillTemplate(template, fields) {
  return template.replace(/\{\{([A-Z0-9_]+)\}\}/g, (full, key) => {
    const value = fields[key];
    return value !== undefined ? value : full;
  });
}

// ---------------------------------------------------------------------
// Repeatable-section renderers — each takes the raw frontmatter array and
// returns the joined HTML for that section, ready to drop into a template
// placeholder like {{PILLARS}}.
// ---------------------------------------------------------------------

function renderPillars(pillars) {
  return (pillars || [])
    .map(
      (p) => `      <div class="card">
        <div class="icon">${escapeHtml(p.icon)}</div>
        <h3>${escapeHtml(p.title)}</h3>
        <p>${escapeHtml(p.description)}</p>
        <a href="${escapeHtml(p.link_href)}">${escapeHtml(p.link_text)}</a>
      </div>`,
    )
    .join('\n');
}

function renderStoryPoints(points) {
  return (points || [])
    .map((p) => `        <p><strong>${escapeHtml(p.bold)}</strong> — ${escapeHtml(p.text)}</p>`)
    .join('\n');
}

function renderValues(values) {
  return (values || [])
    .map(
      (v) => `      <div class="card">
        <div class="icon">${escapeHtml(v.icon)}</div>
        <h3>${escapeHtml(v.title)}</h3>
        <p>${escapeHtml(v.description)}</p>
      </div>`,
    )
    .join('\n');
}

function renderDownloads(downloads) {
  return (downloads || [])
    .map((d) => {
      const hasSwahili = d.sw_title || d.sw_description;
      const swExtraLink =
        d.sw_file_url && d.sw_file_url.trim()
          ? `<a class="btn btn-primary" href="${escapeHtml(d.sw_file_url)}" target="_blank" rel="noopener" style="margin-top:10px;display:inline-block;">Pakua bure</a>`
          : '';
      const swBlock = hasSwahili
        ? `
          <details class="sw-toggle"><summary>SOMA KWA KISWAHILI HAPA</summary><div class="sw-box"><strong>${escapeHtml(d.sw_title)}</strong><p style="margin:6px 0 0;">${escapeHtml(d.sw_description)}</p>${swExtraLink}</div></details>`
        : '';
      return `      <div class="card download-card">
        <div>
          <span class="tag">${escapeHtml(d.tag)}</span>
          <h3>${escapeHtml(d.title)}</h3>
          <p>${escapeHtml(d.description)}</p>${swBlock}
        </div>
        <a class="btn btn-primary" href="${escapeHtml(d.file_url)}" target="_blank" rel="noopener">Download free</a>
      </div>`;
    })
    .join('\n');
}

function renderFeaturedProducts(products) {
  return (products || [])
    .map(
      (p) => `        <div class="card product-card">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}">
          <h3>${escapeHtml(p.name)}</h3>
          <div class="price">${escapeHtml(p.price)}</div>
          <p>${escapeHtml(p.description)}</p>
          <a href="${escapeHtml(p.link_url)}" target="_blank" rel="noopener" class="btn btn-outline">View on Payhip &rarr;</a>
        </div>`,
    )
    .join('\n');
}

function renderHighlights(highlights) {
  return (highlights || [])
    .map(
      (h) => `      <div class="card">
        <div class="icon">${escapeHtml(h.icon)}</div>
        <h3>${escapeHtml(h.title)}</h3>
        <p>${escapeHtml(h.description)}</p>
      </div>`,
    )
    .join('\n');
}

function renderVideos(videos) {
  return (videos || [])
    .map(
      (v) => `      <div class="video-card"><blockquote class="tiktok-embed" cite="https://www.tiktok.com/@herbal_impact/video/${escapeHtml(v.video_id)}" data-video-id="${escapeHtml(v.video_id)}" style="max-width:325px;min-width:250px;margin:0 auto;"><section></section></blockquote></div>`,
    )
    .join('\n');
}

// Builds the blog post-card grid for blog.html directly from content/blog/,
// so it's always in sync with the actual posts — no separate editing surface.
function renderPostCards() {
  if (!fs.existsSync(BLOG_DIR)) return '';
  const files = fs
    .readdirSync(BLOG_DIR)
    .filter((f) => f.endsWith('.md') && !f.endsWith('-sw.md'));

  // Matches the same OUTPUT_MAP convention used by scripts/build-blog.js.
  const SLUG_TO_OUTPUT = {
    '5-everyday-herbs.md': 'blog-1.html',
    'brewing-medicinal-tea.md': 'blog-2.html',
    'daily-wellness-rituals.md': 'blog-3.html',
  };

  return files
    .map((file) => {
      const raw = fs.readFileSync(path.join(BLOG_DIR, file), 'utf8');
      const data = parseFrontMatter(raw);
      const outputName = SLUG_TO_OUTPUT[file] || file.replace(/\.md$/, '.html');
      const swOutputName = outputName.replace('.html', '-sw.html');
      return `      <div class="card blog-card">
        <div class="thumb"><img src="${escapeHtml(data.cover_image)}" alt="${escapeHtml(data.cover_image_alt || data.title)}"></div>
        <div class="meta">${escapeHtml(data.category)} &middot; ${escapeHtml(data.read_time)}</div>
        <h3>${escapeHtml(data.title)}</h3>
        <p>${escapeHtml(data.description)}</p>
        <a href="${escapeHtml(outputName)}">Read article &rarr;</a> &middot; <a href="${escapeHtml(swOutputName)}" class="sw-link">SOMA KWA KISWAHILI HAPA</a>
      </div>`;
    })
    .join('\n');
}

// ---------------------------------------------------------------------
// Main build
// ---------------------------------------------------------------------

function buildFieldMap(data) {
  const fields = {};
  for (const [key, value] of Object.entries(data)) {
    if (Array.isArray(value)) continue; // handled by dedicated renderers below
    fields[key.toUpperCase()] = escapeHtml(value);
  }
  return fields;
}

function buildPage(mdFileName) {
  const mapping = PAGE_MAP[mdFileName];
  if (!mapping) {
    throw new Error(`No page mapping configured for ${mdFileName}. Add it to PAGE_MAP in scripts/build-pages.js.`);
  }

  const mdPath = path.join(PAGES_DIR, mdFileName);
  const raw = fs.readFileSync(mdPath, 'utf8');
  const data = parseFrontMatter(raw);

  const templatePath = path.join(TEMPLATES_DIR, mapping.template);
  const template = fs.readFileSync(templatePath, 'utf8');

  const fields = buildFieldMap(data);

  // Page-specific repeatable sections.
  if (mdFileName === 'home.md') {
    fields.PILLARS = renderPillars(data.pillars);
    fields.STORY_POINTS = renderStoryPoints(data.story_points);
  }
  if (mdFileName === 'about.md') {
    fields.VALUES = renderValues(data.values);
  }
  if (mdFileName === 'downloads.md') {
    fields.DOWNLOADS = renderDownloads(data.downloads);
  }
  if (mdFileName === 'store.md') {
    fields.FEATURED_PRODUCTS = renderFeaturedProducts(data.featured_products);
    fields.HIGHLIGHTS = renderHighlights(data.highlights);
  }
  if (mdFileName === 'videos.md') {
    fields.VIDEOS = renderVideos(data.videos);
  }
  if (mdFileName === 'blog-index.md') {
    fields.POST_CARDS = renderPostCards();
  }

  const html = fillTemplate(template, fields);
  fs.writeFileSync(path.join(ROOT, mapping.output), html, 'utf8');
  console.log('Built ' + mapping.output + ' from content/pages/' + mdFileName);
}

function main() {
  if (!fs.existsSync(PAGES_DIR)) {
    console.warn('No content/pages directory found — nothing to build.');
    return;
  }
  const files = fs.readdirSync(PAGES_DIR).filter((f) => f.endsWith('.md'));
  if (!files.length) {
    console.warn('No Markdown files found in content/pages — nothing to build.');
    return;
  }
  files.forEach(buildPage);
  console.log('\nDone. Built ' + files.length + ' page(s).');
}

main();
